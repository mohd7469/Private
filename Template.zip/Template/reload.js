//var now = new Date();
//var newDate = now.getDate() + ' ' + now.getMonth() + ' ' + now.getFullYear();
//var birthday = '8 5 2016';
//var alert = (birthday === newDate);
//var reloadDate = '24 00 00';
//var todayDate = now.getHours() + ' ' + now.getMinutes() + ' ' + now.getSeconds();
//var confirmReload = (reloadDate == todayDate);
//console.log('time not match : ' + todayDate);
//
//if (confirmReload) {
//
//    console.log('reload page : ' + confirmReload);
////    console.log('time matched : ' + todayDate);
////    $("#reload")[0].click();
//
//}
