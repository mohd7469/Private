/*FOR COUNT DOWN TIMER*/
var launchdatetime = '08/05/2016 05:00:00';

